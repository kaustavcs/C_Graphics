//Done By: Kaustav Ghosh
/*	sample.c (Graphics program)	*/
/*
#include <stdio.h>
#include <graphics.h>

int main()
{
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);

	line(0,getmaxy()/2,getmaxx(),getmaxy()/2);
	line(getmaxx()/2,0,getmaxx()/2,getmaxy());

	setcolor(BLUE);
	circle(getmaxx()/2,getmaxy()/2,150);

	setcolor(GREEN);
	circle(getmaxx()/2,getmaxy()/2,75);

	setcolor(RED);
	circle(getmaxx()/2,getmaxy()/2,25);


	delay(5000);
	closegraph();
	return 0;
}

*/
// C-program for circle drawing
// using Bresenham’s Algorithm
// in computer-graphics
#include <stdio.h>
#include <graphics.h>
 
// Function to put pixels
// at subsequence points
void drawCircle(int xc, int yc, int x, int y)
{
    putpixel(xc+x, yc+y, RED);
    putpixel(xc-x, yc+y, RED);
    putpixel(xc+x, yc-y, RED);
    putpixel(xc-x, yc-y, RED);
    putpixel(xc+y, yc+x, RED);
    putpixel(xc-y, yc+x, RED);
    putpixel(xc+y, yc-x, RED);
    putpixel(xc-y, yc-x, RED);
}
 
// Function for circle-generation
// using Bresenham's algorithm
void circleBres(int xc, int yc, int r)
{
    int x = 0, y = r;
    int d = 3 - 2 * r;
    while (y >= x)
    {
        // for each pixel we will
        // draw all eight pixels
        drawCircle(xc, yc, x, y);
        x++;
 
        // check for decision parameter
        // and correspondingly 
        // update d, x, y
        if (d > 0)
        {
            y--; 
            d = d + 4 * (x - y) + 10;
        }
        else
            d = d + 4 * x + 6;
        drawCircle(xc, yc, x, y);
        delay(50);
    }
}
 
 
// driver function
int main()
{
    int xc = 50, yc = 50, r2 = 30;
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
    circleBres(xc, yc, r2);    // function call
	circleBres(xc, yc, r2);    // function call
circleBres(xc, yc, r2);    // function call
    return 0;
}
